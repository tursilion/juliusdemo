Unzip this file into your Classic99\DSK1 folder.
To start it, select the EDITOR/ASSEMBLER cartridge.
Follow the menus to start Editor Assembler.
Select 5 LOAD PROGRAM FILE
Type: DSK1.JULDEMO

Just sit and watch and listen!


